<?php
/**
 * Seed 15 Highly Detailed & Realistic Demo Posts
 */
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/app.php';
require_once dirname(dirname(__DIR__)) . '/core/Database.php';

$db = Database::getInstance();

$posts = [
    // ==========================================
    // LATEST JOBS (Category 1)
    // ==========================================
    [
        'category_id' => 1,
        'title_en' => 'UPSC Civil Services CSE Online Form 2026',
        'title_hi' => 'यूपीएससी सिविल सेवा सीएसई ऑनलाइन फॉर्म 2026',
        'slug' => 'upsc-civil-services-cse-online-form-2026',
        'excerpt_en' => 'Union Public Service Commission (UPSC) has released the official notification for Civil Services Examination (CSE) 2026 for 1050 vacancies. Apply Online.',
        'excerpt_hi' => 'संघ लोक सेवा आयोग (UPSC) ने 1050 रिक्तियों के लिए सिविल सेवा परीक्षा (CSE) 2026 की आधिकारिक अधिसूचना जारी की है। ऑनलाइन आवेदन करें।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Union Public Service Commission (UPSC)</h3>
                <h4>Civil Services (Preliminary) Examination 2026</h4>
                <p>UPSC has released the recruitment notification for IAS, IPS, IFS, and other Group A/B services. Below are the complete recruitment details including application fees, eligibility criteria, vacancy distribution, and steps to apply online.</p>
                
                <table class="table table-bordered table-striped mt-4">
                    <thead>
                        <tr style="background: #e2e8f0;">
                            <th colspan="2" class="text-center">UPSC CSE 2026 - Important Information</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Notification Date</strong></td>
                            <td>15 May 2026</td>
                        </tr>
                        <tr>
                            <td><strong>Last Date for Online Apply</strong></td>
                            <td>15 June 2026 (till 6:00 PM)</td>
                        </tr>
                        <tr>
                            <td><strong>Admit Card Release</strong></td>
                            <td>August 2026</td>
                        </tr>
                        <tr>
                            <td><strong>Preliminary Exam Date</strong></td>
                            <td>23 August 2026</td>
                        </tr>
                    </tbody>
                </table>

                <h4 class="mt-4">Application Fee Details</h4>
                <ul>
                    <li><strong>General / OBC / EWS:</strong> ₹100/-</li>
                    <li><strong>SC / ST / PH:</strong> ₹0/- (Nil)</li>
                    <li><strong>All Category Female:</strong> ₹0/- (Nil)</li>
                    <li><em>Payment Mode:</em> Online via Net Banking, Debit/Credit Card, or UPI.</li>
                </ul>

                <h4 class="mt-4">Age Limit (As of 01/08/2026)</h4>
                <ul>
                    <li><strong>Minimum Age:</strong> 21 Years</li>
                    <li><strong>Maximum Age:</strong> 32 Years</li>
                    <li>Age relaxation is applicable as per UPSC Civil Services Recruitment rules.</li>
                </ul>

                <h4 class="mt-4">Vacancy Details & Educational Qualification</h4>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr style="background: #e2e8f0;">
                            <th>Service Name</th>
                            <th>Total Posts</th>
                            <th>Eligibility Criteria</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Civil Services Exam (IAS/IPS/IFS etc.)</td>
                            <td>1050</td>
                            <td>Candidates must hold a Bachelor\'s Degree in any stream from a recognized university in India. Final-year appearing candidates are also eligible to apply.</td>
                        </tr>
                    </tbody>
                </table>

                <h4 class="mt-4">How to Apply Online for UPSC CSE 2026</h4>
                <ol>
                    <li>First, candidates must complete the <strong>One Time Registration (OTR)</strong> on the official website of UPSC.</li>
                    <li>After OTR registration, log in using your Email ID / Mobile Number or OTR ID.</li>
                    <li>Go to "Active Examinations" and click on Civil Services (Preliminary) Exam 2026.</li>
                    <li>Fill out Part-I of the application form by providing basic information and selecting your preferences.</li>
                    <li>Pay the application fee (if applicable) and proceed to Part-II.</li>
                    <li>Upload your photograph, signature, and a valid photo identity card in the prescribed format.</li>
                    <li>Select your examination center carefully and submit the final form.</li>
                    <li>Take a printout of the final application form for future reference.</li>
                </ol>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>संघ लोक सेवा आयोग (UPSC)</h3>
                <h4>सिविल सेवा (प्रारंभिक) परीक्षा 2026</h4>
                <p>UPSC ने IAS, IPS, IFS और अन्य ग्रुप A/B सेवाओं के लिए भर्ती अधिसूचना जारी की है। नीचे आवेदन शुल्क, पात्रता मानदंड, रिक्ति विवरण और ऑनलाइन आवेदन करने के चरणों सहित संपूर्ण भर्ती विवरण दिया गया है।</p>
                
                <table class="table table-bordered table-striped mt-4">
                    <thead>
                        <tr style="background: #e2e8f0;">
                            <th colspan="2" class="text-center">यूपीएससी सीएसई 2026 - महत्वपूर्ण जानकारी</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>अधिसूचना जारी तिथि</strong></td>
                            <td>15 मई 2026</td>
                        </tr>
                        <tr>
                            <td><strong>आवेदन करने की अंतिम तिथि</strong></td>
                            <td>15 जून 2026 (शाम 6:00 बजे तक)</td>
                        </tr>
                        <tr>
                            <td><strong>प्रवेश पत्र डाउनलोड तिथि</strong></td>
                            <td>अगस्त 2026</td>
                        </tr>
                        <tr>
                            <td><strong>प्रारंभिक परीक्षा तिथि</strong></td>
                            <td>23 अगस्त 2026</td>
                        </tr>
                    </tbody>
                </table>

                <h4 class="mt-4">आवेदन शुल्क विवरण</h4>
                <ul>
                    <li><strong>सामान्य / ओबीसी / ईडब्ल्यूएस:</strong> ₹100/-</li>
                    <li><strong>एससी / एसटी / दिव्यांग:</strong> ₹0/- (कोई शुल्क नहीं)</li>
                    <li><strong>सभी श्रेणी की महिलाएं:</strong> ₹0/- (कोई शुल्क नहीं)</li>
                </ul>

                <h4 class="mt-4">आयु सीमा (01/08/2026 तक)</h4>
                <ul>
                    <li><strong>न्यूनतम आयु:</strong> 21 वर्ष</li>
                    <li><strong>अधिकतम आयु:</strong> 32 वर्ष</li>
                    <li>नियमानुसार आयु सीमा में छूट लागू है।</li>
                </ul>
            </div>
        ',
        'organization' => 'UPSC',
        'post_date' => '2026-05-15',
        'last_date' => '2026-06-15',
        'exam_date' => '2026-08-23',
        'total_vacancies' => 1050,
        'qualification' => 'Graduate Degree in any stream',
        'age_limit' => '21-32 Years (Relaxation as per rules)',
        'application_fee' => 'General/OBC: ₹100, SC/ST/PH/Female: ₹0',
        'important_links' => json_encode([
            ['label' => 'Apply Online', 'url' => 'https://upsconline.nic.in'],
            ['label' => 'Download Notification', 'url' => 'https://www.upsc.gov.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Application Start', 'date' => '15-05-2026'],
            ['label' => 'Last Date to Apply', 'date' => '15-06-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 1,
        'status' => 'published'
    ],
    [
        'category_id' => 1,
        'title_en' => 'SSC CGL Recruitment Online Form 2026',
        'title_hi' => 'एसएससी सीजीएल भर्ती ऑनलाइन फॉर्म 2026',
        'slug' => 'ssc-cgl-recruitment-online-form-2026',
        'excerpt_en' => 'Staff Selection Commission (SSC) invites online applications for Combined Graduate Level CGL Exam 2026 for various Group B & C vacancies.',
        'excerpt_hi' => 'कर्मचारी चयन आयोग (SSC) विभिन्न ग्रुप B और C रिक्तियों के लिए संयुक्त स्नातक स्तरीय CGL परीक्षा 2026 के लिए ऑनलाइन आवेदन आमंत्रित करता है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Staff Selection Commission (SSC)</h3>
                <h4>Combined Graduate Level (CGL) Examination 2026</h4>
                <p>SSC has announced the Combined Graduate Level (CGL) recruitment examination for 8500 posts. These include positions such as Assistant Section Officer, Inspector of Income Tax, Sub-Inspector, and Auditor.</p>

                <table class="table table-bordered table-striped mt-4">
                    <thead>
                        <tr style="background: #fee2e2;">
                            <th colspan="2" class="text-center" style="color: #991b1b;">SSC CGL 2026 - Important Dates</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Notification Released</strong></td>
                            <td>20 May 2026</td>
                        </tr>
                        <tr>
                            <td><strong>Online Application Period</strong></td>
                            <td>20 May 2026 to 20 June 2026</td>
                        </tr>
                        <tr>
                            <td><strong>Tier-I Exam Date (CBT)</strong></td>
                            <td>September 2026</td>
                        </tr>
                    </tbody>
                </table>

                <h4 class="mt-4">Application Fee</h4>
                <ul>
                    <li><strong>General / OBC / EWS:</strong> ₹100/-</li>
                    <li><strong>SC / ST / Women / Ex-Servicemen:</strong> ₹0/- (Nil)</li>
                </ul>

                <h4 class="mt-4">Eligibility & Qualifications</h4>
                <ul>
                    <li><strong>Age Limit:</strong> 18 to 30 Years (varying by post profile).</li>
                    <li><strong>Educational Criteria:</strong> Bachelor\'s Degree in any stream from a recognized university. Some special posts like Junior Statistical Officer require specific mathematics/statistics background.</li>
                </ul>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>कर्मचारी चयन आयोग (SSC)</h3>
                <h4>संयुक्त स्नातक स्तरीय (CGL) परीक्षा 2026</h4>
                <p>SSC ने 8500 पदों के लिए कंबाइंड ग्रेजुएट लेवल (CGL) भर्ती परीक्षा की घोषणा की है।</p>
            </div>
        ',
        'organization' => 'SSC',
        'post_date' => '2026-05-20',
        'last_date' => '2026-06-20',
        'exam_date' => '2026-09-10',
        'total_vacancies' => 8500,
        'qualification' => 'Bachelor Degree in any stream',
        'age_limit' => '18-30 Years',
        'application_fee' => 'General/OBC: ₹100, SC/ST/Female: ₹0',
        'important_links' => json_encode([
            ['label' => 'Apply Online', 'url' => 'https://ssc.gov.in'],
            ['label' => 'Download Notification', 'url' => 'https://ssc.gov.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Application Start', 'date' => '20-05-2026'],
            ['label' => 'Last Date to Apply', 'date' => '20-06-2026']
        ]),
        'is_featured' => 0,
        'is_trending' => 1,
        'status' => 'published'
    ],
    [
        'category_id' => 1,
        'title_en' => 'IBPS PO Recruitment Online Form 2026',
        'title_hi' => 'आईबीपीएस पीओ भर्ती ऑनलाइन फॉर्म 2026',
        'slug' => 'ibps-po-recruitment-online-form-2026',
        'excerpt_en' => 'Institute of Banking Personnel Selection (IBPS) invites online applications for Probationary Officers (PO) recruitment exam 2026 in various public sector banks.',
        'excerpt_hi' => 'बैंकिंग कार्मिक चयन संस्थान (IBPS) विभिन्न सार्वजनिक क्षेत्र के बैंकों में प्रोबेशनरी ऑफिसर्स (PO) भर्ती परीक्षा 2026 के लिए ऑनलाइन आवेदन आमंत्रित करता है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Institute of Banking Personnel Selection (IBPS)</h3>
                <h4>IBPS CRP PO/MT XIV Recruitment 2026</h4>
                <p>IBPS has released the notification for the recruitment of Probationary Officer (PO) and Management Trainee (MT) positions in nationalized banks.</p>
                <table class="table table-bordered table-striped mt-4">
                    <thead><tr style="background: #e0f2fe;"><th colspan="2" class="text-center">Dates & Fees</th></tr></thead>
                    <tbody>
                        <tr><td><strong>Registration Start</strong></td><td>25 May 2026</td></tr>
                        <tr><td><strong>Registration Last Date</strong></td><td>15 June 2026</td></tr>
                        <tr><td><strong>Preliminary Exam</strong></td><td>October 2026</td></tr>
                    </tbody>
                </table>
                <h4 class="mt-4">Category-Wise Vacancy Breakup</h4>
                <ul>
                    <li>General: 1850 | OBC: 1210 | EWS: 450 | SC: 675 | ST: 315</li>
                    <li><strong>Total Vacancies:</strong> 4500 Posts</li>
                </ul>
                <h4 class="mt-4">Selection Process</h4>
                <p>Candidates will be evaluated through a three-tier system: Prelims Online Exam, Mains Online Exam, and a Face-to-Face Interview.</p>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>बैंकिंग कार्मिक चयन संस्थान (IBPS)</h3>
                <h4>सीआरपी पीओ/एमटी XIV भर्ती 2026</h4>
                <p>आईबीपीएस ने राष्ट्रीयकृत बैंकों में प्रोबेशनरी ऑफिसर (PO) और मैनेजमेंट ट्रेनी (MT) के पदों पर भर्ती के लिए अधिसूचना जारी कर दी है।</p>
            </div>
        ',
        'organization' => 'IBPS',
        'post_date' => '2026-05-25',
        'last_date' => '2026-06-15',
        'exam_date' => '2026-10-12',
        'total_vacancies' => 4500,
        'qualification' => 'Bachelor Degree in any stream',
        'age_limit' => '20-30 Years',
        'application_fee' => 'General/OBC: ₹850, SC/ST/PH: ₹175',
        'important_links' => json_encode([
            ['label' => 'Apply Online', 'url' => 'https://ibps.in'],
            ['label' => 'Official Syllabus', 'url' => 'https://ibps.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Last Date to Apply', 'date' => '15-06-2026']
        ]),
        'is_featured' => 0,
        'is_trending' => 0,
        'status' => 'published'
    ],
    [
        'category_id' => 1,
        'title_en' => 'Indian Navy SSR Sailors Recruitment 2026',
        'title_hi' => 'भारतीय नौसेना एसएसआर नाविक भर्ती 2026',
        'slug' => 'indian-navy-ssr-sailors-recruitment-2026',
        'excerpt_en' => 'Indian Navy invites online applications for Agniveer SSR 01/2026 Batch. 12th Intermediate with Physics and Maths required.',
        'excerpt_hi' => 'भारतीय नौसेना अग्निवीर एसएसआर 01/2026 बैच के लिए ऑनलाइन आवेदन आमंत्रित करती है। भौतिकी और गणित के साथ 12वीं उत्तीर्ण होना आवश्यक है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Join Indian Navy (Nausena Bharti)</h3>
                <h4>Agniveer (SSR) 01/2026 Batch Entry</h4>
                <p>Indian Navy invites unmarried male and female candidates to join as Agniveer Senior Secondary Recruit (SSR).</p>
                <h4 class="mt-4">Physical Standards & Fitness Test</h4>
                <table class="table table-bordered table-striped">
                    <thead><tr style="background: #f1f5f9;"><th>Criteria</th><th>Male</th><th>Female</th></tr></thead>
                    <tbody>
                        <tr><td><strong>Height</strong></td><td>157 cms</td><td>152 cms</td></tr>
                        <tr><td><strong>1.6 Km Run</strong></td><td>06 Min 30 Sec</td><td>08 Min</td></tr>
                        <tr><td><strong>Squats (Uthak Baithak)</strong></td><td>20 Times</td><td>15 Times</td></tr>
                        <tr><td><strong>Pushups</strong></td><td>15 Times</td><td>N/A</td></tr>
                    </tbody>
                </table>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>भारतीय नौसेना (नौसेना भर्ती)</h3>
                <h4>अग्निवीर (SSR) 01/2026 बैच प्रवेश</h4>
                <p>अविवाहित पुरुष और महिला नाविकों के लिए अग्निवीर एसएसआर भर्ती।</p>
            </div>
        ',
        'organization' => 'Indian Navy',
        'post_date' => '2026-05-28',
        'last_date' => '2026-06-18',
        'exam_date' => '2026-07-25',
        'total_vacancies' => 1400,
        'qualification' => '10+2 Intermediate with Physics, Mathematics',
        'age_limit' => 'Born between 01/11/2005 to 30/04/2009',
        'application_fee' => 'All Candidates: ₹550',
        'important_links' => json_encode([
            ['label' => 'Apply Online', 'url' => 'https://joinindiannavy.gov.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Last Date', 'date' => '18-06-2026']
        ]),
        'is_featured' => 0,
        'is_trending' => 1,
        'status' => 'published'
    ],
    [
        'category_id' => 1,
        'title_en' => 'RRB NTPC Graduate Online Form 2026',
        'title_hi' => 'आरआरबी एनटीपीसी ग्रेजुएट ऑनलाइन फॉर्म 2026',
        'slug' => 'rrb-ntpc-graduate-online-form-2026',
        'excerpt_en' => 'Railway Recruitment Board (RRB) has released notification for Non-Technical Popular Categories NTPC Graduate Posts for 11500 vacancies.',
        'excerpt_hi' => 'रेलवे भर्ती बोर्ड (RRB) ने गैर-तकनीकी लोकप्रिय श्रेणियों NTPC ग्रेजुएट पदों की 11500 रिक्तियों के लिए अधिसूचना जारी की है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Railway Recruitment Board (RRB)</h3>
                <h4>RRB Non-Technical Popular Categories (NTPC) Graduate Recruitment 2026</h4>
                <p>Centralized Employment Notice (CEN) for Graduate posts like Goods Guard, Station Master, Commercial Apprentice, and Traffic Assistant.</p>
                <h4 class="mt-4">Post Profile & Vacancies</h4>
                <table class="table table-bordered table-striped">
                    <thead><tr style="background: #fef3c7;"><th>Post Name</th><th>Pay Level</th><th>Total Vacancies</th></tr></thead>
                    <tbody>
                        <tr><td>Station Master</td><td>Level 6</td><td>3400</td></tr>
                        <tr><td>Goods Guard / Train Manager</td><td>Level 5</td><td>4100</td></tr>
                        <tr><td>Senior Commercial cum Ticket Clerk</td><td>Level 5</td><td>4000</td></tr>
                    </tbody>
                </table>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>रेलवे भर्ती बोर्ड (RRB)</h3>
                <h4>आरआरबी गैर-तकनीकी लोकप्रिय श्रेणी (NTPC) भर्ती 2026</h4>
                <p>स्टेशन मास्टर, गुड्स गार्ड और सीनियर क्लर्क पदों के लिए रेलवे भर्ती बोर्ड द्वारा भर्ती अभियान।</p>
            </div>
        ',
        'organization' => 'RRB',
        'post_date' => '2026-05-30',
        'last_date' => '2026-06-30',
        'exam_date' => '2026-11-15',
        'total_vacancies' => 11500,
        'qualification' => 'Bachelor Degree in any stream',
        'age_limit' => '18-33 Years',
        'application_fee' => 'General/OBC: ₹500, SC/ST/PH/Female: ₹250',
        'important_links' => json_encode([
            ['label' => 'Official Portal', 'url' => 'https://indianrailways.gov.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Last Date to Apply', 'date' => '30-06-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 1,
        'status' => 'published'
    ],

    // ==========================================
    // ADMIT CARDS (Category 3)
    // ==========================================
    [
        'category_id' => 3,
        'title_en' => 'UPSC Civil Services Prelims Admit Card 2026',
        'title_hi' => 'यूपीएससी सिविल सेवा प्रीलिम्स प्रवेश पत्र 2026',
        'slug' => 'upsc-civil-services-prelims-admit-card-2026',
        'excerpt_en' => 'Union Public Service Commission (UPSC) has released the admit card for Civil Services Preliminary Exam 2026. Download now.',
        'excerpt_hi' => 'संघ लोक सेवा आयोग (UPSC) ने सिविल सेवा प्रारंभिक परीक्षा 2026 के लिए प्रवेश पत्र जारी कर दिया है। अभी डाउनलोड करें।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Union Public Service Commission (UPSC)</h3>
                <h4>Civil Services Prelims Admit Card / Hall Ticket 2026</h4>
                <p>Candidates who applied for UPSC IAS Prelims can now download their e-Admit Cards. Please follow the instructions carefully before entering the examination hall.</p>
                <h4 class="mt-4">How to Download UPSC Admit Card</h4>
                <ul>
                    <li>Click on the direct link below.</li>
                    <li>Select either <strong>By Registration ID</strong> or <strong>By Roll Number</strong>.</li>
                    <li>Enter your credentials along with your Date of Birth.</li>
                    <li>Enter the Captcha code and click Submit.</li>
                    <li>Print the hall ticket on an A4 sheet. Make sure your photograph is clearly visible.</li>
                </ul>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>संघ लोक सेवा आयोग (UPSC)</h3>
                <h4>यूपीएससी सिविल सेवा प्रीलिम्स प्रवेश पत्र 2026</h4>
                <p>जिन उम्मीदवारों ने यूपीएससी आईएएस प्रारंभिक परीक्षा के लिए आवेदन किया है, वे अब अपना ई-प्रवेश पत्र डाउनलोड कर सकते हैं।</p>
            </div>
        ',
        'organization' => 'UPSC',
        'post_date' => '2026-05-28',
        'last_date' => '2026-08-23',
        'exam_date' => '2026-08-23',
        'total_vacancies' => null,
        'qualification' => 'Admit Card Download',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Download Admit Card', 'url' => 'https://upsconline.nic.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Admit Card Release', 'date' => '28-05-2026'],
            ['label' => 'Exam Date', 'date' => '23-08-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 0,
        'status' => 'published'
    ],
    [
        'category_id' => 3,
        'title_en' => 'SSC CHSL 10+2 Tier I Admit Card 2026',
        'title_hi' => 'एसएससी सीएचएसएल 10+2 टायर I प्रवेश पत्र 2026',
        'slug' => 'ssc-chsl-10-plus-2-tier-i-admit-card-2026',
        'excerpt_en' => 'Staff Selection Commission (SSC) has uploaded the regional Tier I admit cards and application status for CHSL 10+2 Exam 2026.',
        'excerpt_hi' => 'कर्मचारी चयन आयोग (SSC) ने CHSL 10+2 परीक्षा 2026 के लिए क्षेत्रीय टायर I प्रवेश पत्र और आवेदन की स्थिति अपलोड कर दी है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Staff Selection Commission (SSC)</h3>
                <h4>Combined Higher Secondary Level (10+2) Tier I Admit Card 2026</h4>
                <p>Regional websites of the Staff Selection Commission have enabled links to check application status and download admit cards for CHSL Tier-I Exam.</p>
                <h4 class="mt-4">Documents to Carry on Exam Day</h4>
                <ol>
                    <li>Printed copy of the Admit Card.</li>
                    <li>Two recent passport-sized color photographs.</li>
                    <li>A valid original photo ID card (Aadhaar Card, PAN Card, Voter ID, Driving License) having the same Date of Birth printed as in the admit card.</li>
                </ol>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>कर्मचारी चयन आयोग (SSC)</h3>
                <h4>एसएससी सीएचएसएल 10+2 टायर I प्रवेश पत्र 2026</h4>
                <p>कर्मचारी चयन आयोग के क्षेत्रीय वेब पोर्टलों ने सीएचएसएल एडमिट कार्ड डाउनलोड सक्रिय कर दिए हैं।</p>
            </div>
        ',
        'organization' => 'SSC',
        'post_date' => '2026-05-29',
        'last_date' => '2026-07-15',
        'exam_date' => '2026-07-15',
        'total_vacancies' => null,
        'qualification' => 'Intermediate Passed',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Download Admit Card (CR Region)', 'url' => 'http://www.ssc-cr.org']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Admit Card Date', 'date' => '29-05-2026']
        ]),
        'is_featured' => 0,
        'is_trending' => 1,
        'status' => 'published'
    ],
    [
        'category_id' => 3,
        'title_en' => 'NEET UG Exam Admit Card 2026',
        'title_hi' => 'नीट यूजी परीक्षा प्रवेश पत्र 2026',
        'slug' => 'neet-ug-exam-admit-card-2026',
        'excerpt_en' => 'National Testing Agency (NTA) has released the admit cards for NEET UG Entrance Exam 2026. Get download link here.',
        'excerpt_hi' => 'नेशनल टेस्टिंग एजेंसी (NTA) ने NEET UG प्रवेश परीक्षा 2026 के लिए प्रवेश पत्र जारी कर दिया है। डाउनलोड लिंक यहां प्राप्त करें।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>National Testing Agency (NTA)</h3>
                <h4>NEET (UG) - 2026 Entrance Hall Ticket</h4>
                <p>NTA is going to conduct the National Eligibility cum Entrance Test (UG) 2026 on June 10. Admit cards are now live on the official server.</p>
                <h4 class="mt-4">Dress Code & Instructions</h4>
                <p>Candidates must follow the strict dress code prescribed by NTA (light clothes with half sleeves, no big buttons, slippers/sandals with low heels instead of closed shoes). Check your admit card for reporting time slots.</p>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>नेशनल टेस्टिंग एजेंसी (NTA)</h3>
                <h4>नीट (UG) - 2026 प्रवेश परीक्षा हॉल टिकट</h4>
                <p>राष्ट्रीय पात्रता सह प्रवेश परीक्षा (NEET) के एडमिट कार्ड जारी कर दिए गए हैं।</p>
            </div>
        ',
        'organization' => 'NTA / NEET',
        'post_date' => '2026-05-30',
        'last_date' => '2026-06-10',
        'exam_date' => '2026-06-10',
        'total_vacancies' => null,
        'qualification' => '10+2 PCB',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Download NEET Admit Card', 'url' => 'https://neet.nta.nic.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Exam Date', 'date' => '10-06-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 0,
        'status' => 'published'
    ],

    // ==========================================
    // RESULTS (Category 2)
    // ==========================================
    [
        'category_id' => 2,
        'title_en' => 'SBI PO Final Result 2025 Declared',
        'title_hi' => 'एसबीआई पीओ फाइनल रिजल्ट 2025 घोषित',
        'slug' => 'sbi-po-final-result-2025-declared',
        'excerpt_en' => 'State Bank of India (SBI) has declared the final result for Probationary Officers (PO) recruitment 2025. Merit list available.',
        'excerpt_hi' => 'भारतीय स्टेट बैंक (SBI) ने प्रोबेशनरी ऑफिसर्स (PO) भर्ती 2025 का अंतिम परिणाम घोषित कर दिया है। मेरिट लिस्ट देखें।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>State Bank of India (SBI)</h3>
                <h4>SBI Probationary Officer (PO) Final Merit List 2025</h4>
                <p>SBI has released the final results based on Phase-I (Prelims), Phase-II (Mains), and Phase-III (Psychometric Test, Group Exercise & Interview) scores.</p>
                <h4 class="mt-4">How to Check SBI PO Result</h4>
                <ul>
                    <li>Open the official Careers page of SBI.</li>
                    <li>Under recruitment section, click "Declaration of Final Result for PO".</li>
                    <li>A PDF file containing the roll numbers of all provisionally selected candidates will open.</li>
                    <li>Use Ctrl+F to search for your roll number.</li>
                </ul>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>भारतीय स्टेट बैंक (SBI)</h3>
                <h4>एसबीआई पीओ अंतिम चयन सूची 2025</h4>
                <p>एसबीआई ने मुख्य परीक्षा और साक्षात्कार के आधार पर अंतिम परीक्षा परिणाम और मेरिट सूची जारी की है।</p>
            </div>
        ',
        'organization' => 'SBI',
        'post_date' => '2026-05-30',
        'last_date' => null,
        'exam_date' => null,
        'total_vacancies' => 2000,
        'qualification' => 'PO Result Check',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Check Final Result PDF', 'url' => 'https://sbi.co.in/web/careers']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Result Declaration', 'date' => '30-05-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 1,
        'status' => 'published'
    ],
    [
        'category_id' => 2,
        'title_en' => 'UPSC Civil Services CSE 2025 Final Result',
        'title_hi' => 'यूपीएससी सिविल सेवा सीएसई 2025 अंतिम परिणाम',
        'slug' => 'upsc-civil-services-cse-2025-final-result',
        'excerpt_en' => 'Union Public Service Commission (UPSC) has announced the final merit list and toppers list for Civil Services Examination 2025.',
        'excerpt_hi' => 'संघ लोक सेवा आयोग (UPSC) ने सिविल सेवा परीक्षा 2025 के लिए अंतिम मेरिट सूची और टॉपर्स की सूची घोषित कर दी है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Union Public Service Commission (UPSC)</h3>
                <h4>Civil Services Exam (CSE) 2025 Final Merit List</h4>
                <p>UPSC has declared the final results of CSE 2025. A total of 1011 candidates have been recommended for IAS, IFS, IPS, and Central Services Group A and B.</p>
                <h4 class="mt-4">UPSC CSE Toppers List (Top 3)</h4>
                <table class="table table-bordered">
                    <thead><tr style="background: #e0f2fe;"><th>Rank</th><th>Roll Number</th><th>Name of Topper</th></tr></thead>
                    <tbody>
                        <tr><td>Rank 1</td><td>0823451</td><td>Aditya Srivastava</td></tr>
                        <tr><td>Rank 2</td><td>1040523</td><td>Animesh Pradhan</td></tr>
                        <tr><td>Rank 3</td><td>0401205</td><td>Donuru Ananya Reddy</td></tr>
                    </tbody>
                </table>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>संघ लोक सेवा आयोग (UPSC)</h3>
                <h4>सिविल सेवा परीक्षा (CSE) 2025 अंतिम परिणाम</h4>
                <p>यूपीएससी सीएसई 2025 के अंतिम परिणाम घोषित कर दिए गए हैं। कुल 1011 उम्मीदवारों की सिफारिश की गई है।</p>
            </div>
        ',
        'organization' => 'UPSC',
        'post_date' => '2026-05-29',
        'last_date' => null,
        'exam_date' => null,
        'total_vacancies' => 1011,
        'qualification' => 'UPSC Marks',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Download Final Result List', 'url' => 'https://www.upsc.gov.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Result Date', 'date' => '29-05-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 1,
        'status' => 'published'
    ],
    [
        'category_id' => 2,
        'title_en' => 'CBSE Class 12th Board Result 2026',
        'title_hi' => 'सीबीएसई कक्षा 12वीं बोर्ड परिणाम 2026',
        'slug' => 'cbse-class-12th-board-result-2026',
        'excerpt_en' => 'Central Board of Secondary Education (CBSE) has declared the Class XII Senior Secondary School Certificate results.',
        'excerpt_hi' => 'केंद्रीय माध्यमिक शिक्षा बोर्ड (CBSE) ने कक्षा XII सीनियर सेकेंडरी स्कूल सर्टिफिकेट परीक्षा परिणाम घोषित कर दिया है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Central Board of Secondary Education (CBSE)</h3>
                <h4>Class XII Board Examination Results 2026</h4>
                <p>CBSE has officially declared the Class 12th Board exam results. Students can check their results online using their roll number and school ID.</p>
                <h4 class="mt-4">How to check via Digilocker</h4>
                <p>Students can download their digital marksheets, passing certificates, and migration certificates directly through DigiLocker by linking their Aadhaar numbers.</p>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>केंद्रीय माध्यमिक शिक्षा बोर्ड (CBSE)</h3>
                <h4>कक्षा 12वीं बोर्ड परीक्षा परिणाम 2026</h4>
                <p>सीबीएसई ने आधिकारिक तौर पर 12वीं बोर्ड का रिजल्ट घोषित कर दिया है। छात्र अपने स्कूल कोड और रोल नंबर का उपयोग करके इसे देख सकते हैं।</p>
            </div>
        ',
        'organization' => 'CBSE',
        'post_date' => '2026-05-28',
        'last_date' => null,
        'exam_date' => null,
        'total_vacancies' => null,
        'qualification' => 'Class 12 Board',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Check Result Link 1', 'url' => 'https://cbseresults.nic.in'],
            ['label' => 'Check Result Link 2', 'url' => 'https://results.cbse.nic.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Release Date', 'date' => '28-05-2026']
        ]),
        'is_featured' => 0,
        'is_trending' => 0,
        'status' => 'published'
    ],

    // ==========================================
    // ANSWER KEYS (Category 4)
    // ==========================================
    [
        'category_id' => 4,
        'title_en' => 'SSC GD Constable Answer Key 2026',
        'title_hi' => 'एसएससी जीडी कांस्टेबल उत्तर कुंजी 2026',
        'slug' => 'ssc-gd-constable-answer-key-2026',
        'excerpt_en' => 'Staff Selection Commission (SSC) has released the tentative answer keys along with Response Sheets for GD Constable Exam.',
        'excerpt_hi' => 'कर्मचारी चयन आयोग (SSC) ने जीडी कांस्टेबल परीक्षा के लिए रिस्पांस शीट के साथ अनंतिम उत्तर कुंजी जारी कर दी है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Staff Selection Commission (SSC)</h3>
                <h4>Constable GD (General Duty) Exam 2026 Answer Key</h4>
                <p>Candidates who appeared for the computer-based test can log in and download their response sheets. Representations against any incorrect answer key can be submitted online.</p>
                <h4 class="mt-4">How to Raise Objections</h4>
                <p>Objections can be submitted from May 27 to June 03 on payment of ₹100/- per question challenged. No requests will be entertained after the deadline.</p>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>कर्मचारी चयन आयोग (SSC)</h3>
                <h4>कांस्टेबल जीडी परीक्षा 2026 उत्तर कुंजी</h4>
                <p>एसएससी जीडी परीक्षा की उत्तर कुंजी और रिस्पांस शीट जारी कर दी गई है। उम्मीदवार 100 रुपये प्रति आपत्ति शुल्क देकर चुनौतियां दर्ज करा सकते हैं।</p>
            </div>
        ',
        'organization' => 'SSC',
        'post_date' => '2026-05-27',
        'last_date' => '2026-06-03',
        'exam_date' => null,
        'total_vacancies' => 26146,
        'qualification' => 'Class 10 Matric',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Download Answer Key / Response Sheet', 'url' => 'https://ssc.digialm.com']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Key Released', 'date' => '27-05-2026'],
            ['label' => 'Objection Last Date', 'date' => '03-06-2026']
        ]),
        'is_featured' => 0,
        'is_trending' => 1,
        'status' => 'published'
    ],
    [
        'category_id' => 4,
        'title_en' => 'JEE Main Session 2 Answer Key 2026',
        'title_hi' => 'जेईई मेन सत्र 2 उत्तर कुंजी 2026',
        'slug' => 'jee-main-session-2-answer-key-2026',
        'excerpt_en' => 'NTA has uploaded the provisional answer key and response sheets for Joint Entrance Examination JEE Main Session 2 Exam.',
        'excerpt_hi' => 'एनटीए ने संयुक्त प्रवेश परीक्षा जेईई मेन सत्र 2 परीक्षा के लिए अनंतिम उत्तर कुंजी और प्रतिक्रिया पत्रक अपलोड कर दिए हैं।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>National Testing Agency (NTA)</h3>
                <h4>JEE Main 2026 Session 2 Provisional Key</h4>
                <p>NTA has released the scanned images of OMR response sheets and answer keys for JEE Main Session 2. Candidates can compute their estimated score using the marking scheme.</p>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>नेशनल टेस्टिंग एजेंसी (NTA)</h3>
                <h4>जेईई मेन 2026 सत्र 2 अनंतिम कुंजी</h4>
                <p>जेईई मेन परीक्षा सत्र 2 के लिए रिस्पांस शीट जारी कर दी गई है। छात्र प्रश्न पत्र कोड के अनुसार मिलान कर सकते हैं।</p>
            </div>
        ',
        'organization' => 'NTA',
        'post_date' => '2026-05-26',
        'last_date' => '2026-05-30',
        'exam_date' => null,
        'total_vacancies' => null,
        'qualification' => '10+2 Intermediate PCM',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Download Response Sheet & Answer Key', 'url' => 'https://jeemain.nta.nic.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Release Date', 'date' => '26-05-2026']
        ]),
        'is_featured' => 0,
        'is_trending' => 0,
        'status' => 'published'
    ],

    // ==========================================
    // SYLLABUS (Category 5)
    // ==========================================
    [
        'category_id' => 5,
        'title_en' => 'UP Police Constable Written Exam Syllabus 2026',
        'title_hi' => 'यूपी पुलिस कांस्टेबल लिखित परीक्षा पाठ्यक्रम 2026',
        'slug' => 'up-police-constable-written-exam-syllabus-2026',
        'excerpt_en' => 'UPPRPB has provided the detailed syllabus and exam pattern for the recruitment of 60244 Constable posts.',
        'excerpt_hi' => 'UPPRPB ने 60244 कांस्टेबल पदों की भर्ती के लिए विस्तृत लिखित परीक्षा पाठ्यक्रम और पैटर्न प्रदान किया है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>Uttar Pradesh Police Recruitment Board (UPPRPB)</h3>
                <h4>UP Police Constable Exam Syllabus & Pattern 2026</h4>
                <p>The written exam will consist of 150 objective-type questions carrying a total of 300 marks. There is a negative marking of 0.5 marks for each wrong answer.</p>
                <h4 class="mt-4">Subject-Wise Mark Distribution</h4>
                <ul>
                    <li>General Knowledge: 38 Questions (76 Marks)</li>
                    <li>General Hindi: 37 Questions (74 Marks)</li>
                    <li>Numerical Aptitude: 38 Questions (76 Marks)</li>
                    <li>Mental Ability / Reasoning: 37 Questions (74 Marks)</li>
                </ul>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>उत्तर प्रदेश पुलिस भर्ती एवं प्रोन्नति बोर्ड (UPPRPB)</h3>
                <h4>यूपी पुलिस कांस्टेबल परीक्षा पैटर्न और सिलेबस</h4>
                <p>लिखित परीक्षा में कुल 300 अंकों के 150 वस्तुनिष्ठ प्रकार के प्रश्न होंगे। प्रत्येक गलत उत्तर के लिए 0.5 अंक की नकारात्मक मार्किंग होगी।</p>
            </div>
        ',
        'organization' => 'UPPRPB',
        'post_date' => '2026-05-24',
        'last_date' => null,
        'exam_date' => null,
        'total_vacancies' => 60244,
        'qualification' => 'Class 12th Intermediate',
        'age_limit' => '',
        'application_fee' => '',
        'important_links' => json_encode([
            ['label' => 'Download Official Syllabus PDF', 'url' => 'http://uppbpb.gov.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Updated Syllabus Released', 'date' => '24-05-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 0,
        'status' => 'published'
    ],

    // ==========================================
    // ADMISSIONS (Category 6)
    // ==========================================
    [
        'category_id' => 6,
        'title_en' => 'NTA CUET UG Admission Online Form 2026',
        'title_hi' => 'एनटीए सीयूईटी यूजी प्रवेश ऑनलाइन फॉर्म 2026',
        'slug' => 'nta-cuet-ug-admission-online-form-2026',
        'excerpt_en' => 'National Testing Agency (NTA) invites online applications for Common University Entrance Test (CUET) UG Admission 2026.',
        'excerpt_hi' => 'नेशनल टेस्टिंग एजेंसी (NTA) कॉमन यूनिवर्सिटी एंट्रेंस टेस्ट (CUET) UG प्रवेश 2026 के लिए ऑनलाइन आवेदन आमंत्रित करती है।',
        'content_en' => '
            <div class="job-detail-content">
                <h3>National Testing Agency (NTA)</h3>
                <h4>Common University Entrance Test (CUET UG) 2026</h4>
                <p>CUET (UG) provides a single-window opportunity to candidates seeking admission in undergraduate programs across any of the Central Universities in India (DU, BHU, JNU, AMU, etc.).</p>
                <h4 class="mt-4">Application Form Instructions</h4>
                <p>Candidates can select multiple university programs and choice subjects. Form filling involves uploading school certificates, selecting domains/languages, and selecting exam slot centers.</p>
            </div>
        ',
        'content_hi' => '
            <div class="job-detail-content">
                <h3>नेशनल टेस्टिंग एजेंसी (NTA)</h3>
                <h4>कॉमन यूनिवर्सिटी एंट्रेंस टेस्ट (CUET UG) 2026</h4>
                <p>सीयूईटी (यूजी) परीक्षा भारत के किसी भी केंद्रीय विश्वविद्यालय (डीयू, बीएचयू, जेएनयू, एएमयू आदि) में प्रवेश के लिए आयोजित की जाती है।</p>
            </div>
        ',
        'organization' => 'NTA / CUET',
        'post_date' => '2026-05-23',
        'last_date' => '2026-06-25',
        'exam_date' => '2026-07-20',
        'total_vacancies' => null,
        'qualification' => 'Passed / Appearing 10+2 Intermediate',
        'age_limit' => 'No age limit for CUET UG',
        'application_fee' => 'Depends on number of subjects chosen',
        'important_links' => json_encode([
            ['label' => 'Apply Online', 'url' => 'https://cuet.samarth.ac.in']
        ]),
        'important_dates' => json_encode([
            ['label' => 'Last Date to Apply', 'date' => '25-06-2026']
        ]),
        'is_featured' => 1,
        'is_trending' => 1,
        'status' => 'published'
    ]
];

foreach ($posts as $post) {
    // Delete existing demo posts if they already exist to overwrite with detailed version
    $db->delete('posts', 'slug = ?', [$post['slug']]);
    
    // Insert detailed version
    $db->insert('posts', $post);
    echo "Inserted detailed post: " . $post['title_en'] . "<br>\n";
}
echo "Seeding of 15 highly detailed demo posts completed successfully.";
